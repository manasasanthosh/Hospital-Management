<?php

echo '  <section id="contact">
<div class="container">
  <div class="row">
    <div class="col-md-12 text-center">
      <h2 class="section-title">Contact Us</h2>
    </div>
  </div>

  <div class="row justify-content-center">
    <div class="col-lg-6 col-md-7">
      <div class="info">
        <div>
          <i class="fa fa-map-marker"></i>
          <p>vijaynagar,rpc layout<br>bangalore 560026</p>
        </div>

        <div>
          <i class="fa fa-envelope"></i>
          <p>megha@gmail.com</p>
        </div>

        <div>
          <i class="fa fa-phone"></i>
          <p>+1 9008947588</p>
        </div>

      </div>
    </div>

  </div>
</div>
</section>

<footer class="site-footer">
<div class="bottom">
  <div class="container">
    <div class="row">

      <div class="col-lg-6 col-xs-12 text-lg-left text-center">
        <p class="copyright-text">
          © Hospital
        </p>
        <div class="credits">
          
        
         Presented by <a href="#">Vasi Games</a>
        </div>
      </div>

      
    </div>
  </div>
</div>
</footer>';

?>